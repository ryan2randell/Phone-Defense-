package com.phonedefense.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("phone_defense_local", MODE_PRIVATE) }
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "Phone Defense"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Local evidence prototype"
            textSize = 16f
            setPadding(0, 8, 0, 16)
        })
        root.addView(TextView(this).apply {
            text = "This starter version stores test incidents on this phone. It does not yet monitor unlock attempts, take photos, read location, or send email."
            textSize = 14f
            setPadding(0, 0, 0, 16)
        })
        root.addView(Button(this).apply {
            text = "Add test incident"
            setOnClickListener {
                val incidents = loadIncidents()
                incidents.put(JSONObject().apply {
                    put("time", System.currentTimeMillis())
                    put("status", "Test incident — no sensor evidence")
                })
                saveIncidents(incidents)
                renderIncidents()
            }
        })
        root.addView(Button(this).apply {
            text = "Clear all local test incidents"
            setOnClickListener {
                prefs.edit().remove("incidents").apply()
                renderIncidents()
            }
        })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 0)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
        renderIncidents()
    }

    private fun loadIncidents(): JSONArray = try {
        JSONArray(prefs.getString("incidents", "[]"))
    } catch (_: Exception) {
        JSONArray()
    }

    private fun saveIncidents(items: JSONArray) {
        prefs.edit().putString("incidents", items.toString()).apply()
    }

    private fun renderIncidents() {
        list.removeAllViews()
        val items = loadIncidents()
        if (items.length() == 0) {
            list.addView(TextView(this).apply {
                text = "No incidents saved yet."
                textSize = 16f
                setPadding(0, 8, 0, 8)
            })
            return
        }
        for (i in items.length() - 1 downTo 0) {
            val item = items.optJSONObject(i) ?: continue
            val time = DateFormat.getDateTimeInstance().format(Date(item.optLong("time")))
            list.addView(TextView(this).apply {
                text = "$time\n${item.optString("status")}"
                textSize = 15f
                setPadding(12, 12, 12, 12)
                gravity = Gravity.CENTER_VERTICAL
            })
        }
    }
}
